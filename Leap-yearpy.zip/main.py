year=int(input("Enter a year:"))
if(year%4==0):
   print("The given year is a leap")
else:
   print("The given year is not a leap")